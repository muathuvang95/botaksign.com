<?php
/**
 * printshop functions and definitions
 *
 * @package Netbase
 */

/**
 * Define theme constants
 */
function printshop_theme_enqueue_styles() {
	// wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css',false,'1.1','all');
	wp_enqueue_style( 'printshop-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		array()
	);
	if( is_front_page () ) {
		wp_enqueue_script( 'printshop-gift-customize', get_stylesheet_directory_uri() . '/js/customize.js', array(), '', true );
	}
}
add_action( 'wp_enqueue_scripts', 'printshop_theme_enqueue_styles',99 );

function override_mce_options($initArray) {
	$opts = '*[*]';
	$initArray['valid_elements'] = $opts;
	$initArray['extended_valid_elements'] = $opts;
	return $initArray;
}
add_filter('tiny_mce_before_init', 'override_mce_options');