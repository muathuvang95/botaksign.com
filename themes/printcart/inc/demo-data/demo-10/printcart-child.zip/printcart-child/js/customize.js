( function ( $ ) {
'use strict';
$( document ).ready( function () {
setInterval(function() {
$(".vc-tab-product-content .tab-panel .product").each(function() {
if($(this).find('del').length>0) {
$(this).find('.woocommerce-Price-amount').unwrap();
var amount = $(this).find('.woocommerce-Price-amount');
amount.first().insertAfter(amount.last());
}
});
}, 1250);
        //make it global access
        window.updateErrorMessage = function() {
        var txt = $('#es_txt_email').val();
        if(!txt){
        alert('Please enter email address!');
        }else if(!validateEmail(txt)){
        alert('Please provide a valid email address!');
        }else{
        $('#mc4wp-form-1').submit();
        }
        return false;
        }
    })
} ( jQuery ) )

function es_submit_page() {
updateErrorMessage();

return false;

}
function validateEmail(email) {
var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
return re.test(email);
}