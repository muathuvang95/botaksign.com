'use strict';
jQuery(document).ready(function () {
	jQuery( "<style>table.compare-list tr.description td ul { list-style: none !important; }</style>" ).appendTo( "head" );
});