<?php
function printshop_theme4_enqueue_styles() {
	if(is_rtl()){
		wp_enqueue_style( 'printshop-child4-style-rtl', get_stylesheet_directory_uri() . '/rtl.css' );
	}	
	wp_enqueue_style( 'printshop-child4-style', get_stylesheet_directory_uri() . '/style.css' );
    /*wp_enqueue_style( 'magnific-popup', get_stylesheet_directory_uri() . '/js/magnific-popup/magnific-popup.css' );*/
	if( is_front_page () ){
        /*wp_enqueue_script( 'magnific-popup', get_stylesheet_directory_uri() . '/js/magnific-popup/jquery-magnific-popup.min.js', array(), '', false );*/
		wp_enqueue_script( 'print_home6', get_stylesheet_directory_uri() . '/js/home4.js', array('jquery'), '', true );
	}
}
add_action( 'wp_enqueue_scripts', 'printshop_theme4_enqueue_styles', 99 );

