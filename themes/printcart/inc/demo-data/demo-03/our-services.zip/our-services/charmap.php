<?php $icons = array();
$icons['our-services']['overlapping-circles'] = array("class"=>'overlapping-circles',"tags"=>'overlapping-circles',"unicode"=>'');
$icons['our-services']['psd-file'] = array("class"=>'psd-file',"tags"=>'psd-file',"unicode"=>'');
$icons['our-services']['social'] = array("class"=>'social',"tags"=>'social',"unicode"=>'');
$icons['our-services']['technology'] = array("class"=>'technology',"tags"=>'technology',"unicode"=>'');
$icons['our-services']['print'] = array("class"=>'print',"tags"=>'print',"unicode"=>'');
$icons['our-services']['pencil'] = array("class"=>'pencil',"tags"=>'pencil',"unicode"=>'');