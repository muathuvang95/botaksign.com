<?php
// require get_theme_file_path() . '/js_composer/vc.php';

if( ! function_exists('printshop_embed_style') ) {

  function printshop_embed_style() {
    
    wp_enqueue_style( 'oswald', 'https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700',false,'1.1','all');
    wp_enqueue_style( 'lobster', 'https://fonts.googleapis.com/css?family=Lobster',false,'1.1','all');
    // wp_enqueue_style( 'printshop', get_template_directory_uri() . '/assets/css/style.min.css',false,'1.1','all');
    if(is_rtl()){
        wp_enqueue_style( 'printshop-child-style-rtl', get_stylesheet_directory_uri() . '/rtl.css', array());
    }
    wp_enqueue_style( 'printshop-child-style',
      get_stylesheet_directory_uri() . '/style.css',
      array()
    );
	if( is_front_page () ) {
		// wp_enqueue_script( 'print_home7', get_stylesheet_directory_uri() . '/js/customize.js', array('jquery'), '', true );
	}
  }

  add_action( 'wp_enqueue_scripts', 'printshop_embed_style' );
}