jQuery(document).ready(function($) {
setInterval(function() {
		if ($('.products .product .product-action .button.compare').length>0) {
			$('.products .product .product-action .button.compare').addClass('bt-4');
		}
	$('.products .product .product-action .button.wishlist-btn .yith-wcwl-add-to-wishlist .show  a').show();
}, 1000);
	});