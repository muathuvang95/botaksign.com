<?php
/**
 * printshop functions and definitions
 *
 * @package Netbase
 */

/**
 * Define theme constants
 */
function printshop_theme_enqueue_styles() {
	if(!is_search()) {
		//wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css',false,'1.1','all');
	}
	// wp_enqueue_style('nbcore_woo_style', get_template_directory_uri() . '/assets/netbase/css/woocommerce.css', array(), NBT_VER);
	wp_enqueue_style( 'printshop-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		array()
	);
	wp_enqueue_script( 'printshop-gift-customize', get_stylesheet_directory_uri() . '/js/customize.js', array(), '', true );
}
add_action( 'wp_enqueue_scripts', 'printshop_theme_enqueue_styles',99 );