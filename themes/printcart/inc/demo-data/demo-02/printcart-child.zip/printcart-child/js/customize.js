jQuery(document).ready(function ($) {
var win = jQuery(window);
if(win.width()<=768) {
jQuery('.vc_row:not(#home-testimonials)').not(':first').not(':last').attr('style','margin-top: 17px !important;');
jQuery('.vc_column-inner').not(':first').not(':last').attr('style','margin-top: 17px !important;');
jQuery('.vc_row[data-vc-full-width]:last .vc_column-inner').removeAttr('style');
}
var w = jQuery('.container').width();
if (w>1366 && w<=1470 && win.width()>1366 && win.width()<=1470) {
jQuery( "<style>.container { max-width: " + (win.width()-10) + "px; width: " + (win.width()-10) + "px; }</style>" ).appendTo( "head" );
}
jQuery(".mega-sub-menu .mega-menu-item .mega-menu-link .mega-description-group").each(function() {
jQuery(this).parent('.mega-menu-link').text(jQuery(this).find('.mega-menu-title').text());
});
});